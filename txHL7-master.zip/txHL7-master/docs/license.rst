License
=======

.. include::  ../LICENSE
   :literal:

