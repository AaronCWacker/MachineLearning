
http://txHL7.readthedocs.org/

Project formerly known as "twisted-hl7".

Setup environment::

    make env

Run tests (via twisted's trial)::

    make tests


.. image::
   https://travis-ci.org/johnpaulett/txHL7.png
   :target: https://travis-ci.org/johnpaulett/txHL7
